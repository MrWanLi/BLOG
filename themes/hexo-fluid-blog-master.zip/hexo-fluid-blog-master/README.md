本仓库是 Fluid 项目组官方创建，用于 [Fluid 主题](https://github.com/fluid-dev/hexo-theme-fluid)展示以及发布一些 Hexo 与主题相关的文章。

如果你有相关文章想投稿，可以通过 [Pull Request](https://github.com/fluid-dev/hexo-fluid-blog/pulls) 方式提交（文中图片可暂时使用自己的外链或存放在 source 里），不要忘记文章头部留下自己的原文链接（[格式参考](https://raw.githubusercontent.com/fluid-dev/hexo-fluid-blog/master/source/_posts/hexo-darkmode.md)）。
